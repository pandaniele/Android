package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2<btnreset> extends AppCompatActivity {
Button btnreset;
//c'e' il prete alla festa
        TextView txtmesaggio;
        Button lancia;
Button btt;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // c'e' la festa. COLLEGAMENTO A XML
        setContentView(R.layout.activity_main);
//R.???????



        // esxtras dentro l'oggetto bundle e contengono una chiave
        btnreset= (Button)findViewById(R.id.button4);
        btt= (Button)findViewById(R.id.button2);
        lancia= (Button)findViewById(R.id.button3);

        //collegamneto a prete
        txtmesaggio= (TextView)findViewById(R.id.textView2);//casting per trasformare oggetto in bottone
    }
    public void azzera(View w) {
        txtmesaggio.setText("");
    }
    public void toast(View view) {

        Toast toast = Toast.makeText(this, txtmesaggio.getText(),
                //make test ==new
                Toast.LENGTH_SHORT);
        toast.show();
//api apk

    }
    public void lancia2(View v){
            Intent i=new Intent(getApplicationContext(), SecondaActivity.class);
            //acrtivity da far partire
            i.putExtra("messaggio",txtmesaggio.getText()); //?
            startActivity(i);
            //
//indicce valoore---- chiave-valore=array eterogeneo di dati
       // 0 100 int       numero 1000
        //                 an ciao
}

    }

//rename