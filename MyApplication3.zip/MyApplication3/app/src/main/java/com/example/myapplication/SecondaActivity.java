package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class SecondaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seconda);

//passo degli attributi alla seconda activiti, come???
        Intent i = getIntent();
        String messaggioricevuto = i.getStringExtra("messaggio");

        Toast to = Toast.makeText(getApplicationContext(), messaggioricevuto.toString(), Toast.LENGTH_SHORT);
        to.show();
        //tostring---->
    }
}
