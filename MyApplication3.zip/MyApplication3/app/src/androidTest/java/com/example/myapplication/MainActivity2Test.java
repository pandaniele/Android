package com.example.myapplication;

import junit.framework.TestCase;

public class MainActivity2Test extends TestCase {

}